# data500_v5_Pat1to500 — Singapore synthetic chronic-care cohort, 500 patients (engine v0.5.1)

_Last updated: 2026-07-27 10:15:00 SGT (UTC+08:00)._

> ⚠️ Research-only, synthetic, `draft_pending_review`. Not a population sample, medical record, or
> clinical decision-support tool. The knowledge base is unsigned.

An **independent** 500-patient cohort covering Singapore's top-five primary-care chronic conditions,
generated 2026-07-27 from **Synthea-SG engine v0.5.1-live-kb-evidence-consistent-research** against KB
contract `0.2.5-draft` (`kb-mmb5/kb/thresholds.json`, sha256 `ba615011b520f3ba…`).

```
seed 20260727 · 500 patients × 10 completed visits = 5,000 visits · latest visit June 2026 · 158 MB
```

This is a **separate draw**, not a superset of `data200_v5_Pat1to200` (seed `20260621`). Patient IDs overlap by
construction (`SG-SYN-000001`…`SG-SYN-000500`) but the patients are different; do not pool the two
cohorts by ID.

**Batch 2 is available** at `../data500_v5_Pat501to1000/` — patients `SG-SYN-000501`…`SG-SYN-001000`, same
calibrated statistics, disjoint IDs. The two pool into a 1,000-patient cohort with each stratum within
one patient of its exact 1,000-share. This cohort was produced by engine v0.5.1 and `Pat501to1000` by v0.5.2;
the versions are output-compatible (an un-offset v0.5.2 run reproduces this cohort exactly).

## Cohort composition

Bands are apportioned from the calibrated per-200 reference distribution by largest remainder, so
every stratum lands within **0.5 patients** of its exact share.

| Stratum | Composition |
|---|---|
| Age at visit 1 | 50–54: 93 · 55–59: 88 · 60–64: 90 · 65–69: 82 · 70–74: 65 · 75–79: 45 · 80–84: 22 · 85–89: 15 |
| Ethnicity | Chinese 370 · Malay 68 · Indian 45 · Other 17 |
| Sex | female 284 · male 216 |
| Conditions per patient | 1: 100 · 2: 175 · 3: 150 · 4: 38 · 5: 37 |
| Condition prevalence (incl. incident) | hypertension 371 · hyperlipidaemia 332 · T2DM 229 · obesity 195 · CKD 185 |

Baseline disease slots (1,237) exhaust exactly against the calibrated 145/130/90/75/55 ratio.

## Engine behaviour in this cohort

| Metric | Value |
|---|---|
| Final-visit target attainment (BP / HbA1c / LDL) | 55.0 / 67.2 / 71.4 % |
| Mean active agents at final visit (max) | 4.3 (10) |
| Patients with ≥1 adverse event / total events | 117 / 155 |
| Hypoglycaemia events / deprescribing step-downs | 28 / 24 |
| Poor responders (≥1 drug class) | 170 |
| Mean modeled cumulative mortality risk over the window | 5.8 % |

## Verification

| Check | Result |
|---|---|
| Determinism — two independent runs, byte comparison | 0 / 500 patient files differ; manifest identical |
| Structure | 500 unique IDs, all 10/10 visits completed, all final visits June 2026, no date-ordering faults |
| Band calibration | max deviation 0.50 patients across age, ethnicity and disease-count strata |
| Evidence consistency (v0.5 rule) | 0 contradictory safety checks, 0 false information gaps, 13,243 measurement-backed checks over 5,000 visits |
| Physiological ranges | SBP 109.6–173.3 · HbA1c 5.5–9.2 · LDL 0.7–4.6 · eGFR 31.0–100.7 · K⁺ 3.8–5.6 — no NaN, no negatives, floors held |
| Test suite (8 tests) + causal architecture spike | pass |

## Layout

```
data500_v5_Pat1to500/
  patients/SG-SYN-000001.json … SG-SYN-000500.json   one file per patient, 10 visits each
  manifest.csv                                        id, age, sex, ethnicity, disease count, visit-10 date, path
  RUN_SUMMARY.json                                    provenance, KB hash, cohort dynamics, limitations
```

## Still open — read before analysing

Carried unresolved from `synthea-sg/docs/ENGINE_V0.4_CRITIQUE.md` and re-confirmed in this cohort:

- **A1** — attrition is *not* enacted here: all 500 patients complete 10 visits.
  `RUN_SUMMARY…attrition_enacted_v0_4` (61 deaths, 65 dropouts) describes a parallel 650-candidate
  pool that never enters the engine.
- **A2** — PCSK9 (evolocumab) reaches **136/332 = 41%** of dyslipidaemics against ~1–2% real-world
  use; the referral is not adherence-gated and the drug is never deprescribed.
- **B1** — LDL 71.4% and HbA1c 67.2% attainment are optimistic for real primary care, largely
  because of A2.
- **B2** — `context_priors.yaml` is fingerprinted but never loaded; the engine's hardcoded priors
  already drift from it.
- **B3 / C1** — 65 non-frail patients carry ≥8 active agents with no polypharmacy review.
- SG-FRS is a non-validated categorical proxy; treatment-effect magnitudes are ASSUMED
  (`docs/ASSUMPTIONS.md`).

**Medication-utilisation, cost and attrition analyses on this cohort are not valid until A1 and A2
are fixed.** Target-attainment and consultation-structure work is unaffected.

## Reproduce

```bash
cd synthea-sg
JAVA_HOME=/path/to/jdk17 ./gradlew generateProvisional \
  -Ppatients=500 -Pseed=20260727 -Poutput=../data500_v5_Pat1to500
```

Requires `kb-mmb5` at KB contract `0.2.5-draft`; the generator refuses to run against any other
version. Authoritative docs: `synthea-sg/docs/ENGINE_V0.5_UPDATE.md`, `ENGINE_V0.4_CRITIQUE.md`,
`ASSUMPTIONS.md`.
